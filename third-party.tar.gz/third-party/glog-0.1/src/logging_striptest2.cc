// Copyright 2007 Google Inc. All Rights Reserved.
// Author: Sergey Ioffe

#define GOOGLE_STRIP_LOG 2

// Include the actual test.
#include "logging_striptest_main.cc"
